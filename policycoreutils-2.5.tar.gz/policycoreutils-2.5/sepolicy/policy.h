#include <apol/policy.h>
extern apol_policy_t *global_policy;
extern PyObject *wrap_info(PyObject *self, PyObject *args);
extern void init_info (PyObject *m);
extern PyObject *wrap_search(PyObject *self, PyObject *args);


